<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Copyright" content="All Rights Reserved btoe.cn" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>热压罐,西安排布机_西安热压罐_西安预浸料设备_西安热压成型工艺西安液压釜-陕西神鹰装备科技有限公司-陕西神鹰装备科技有限公司</title>
<meta name="keywords" content="西安排布机_西安热压罐设备|西安预浸料设备|西安热压成型工艺|西安液压釜|西安缠绕机" />
<meta name="description" content="西安热压罐认准陕西神鹰装备科技有限公司,神鹰专注于复材设备研发和制品生产,拥有建设大型生产基地,实力浑厚,经验丰富,同时提供热压罐租赁或复合材料产品代加工,有这方面需求的客户欢迎来电咨询!" />
<link href="/templates/pc_wjdh/css/css.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" media="screen" href="/templates/pc_wjdh/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" media="screen" href="/templates/pc_wjdh/css/swiper-3.4.2.min.css" />
<link rel="stylesheet" type="text/css" media="screen" href="/templates/pc_wjdh/css/common.css" />
<script src="/templates/pc_wjdh/js/n/baidupush.js"></script>
<script language="Javascript">  
document.oncontextmenu=new Function("event.returnValue=false");  
document.onselectstart=new Function("event.returnValue=false");  
</script>
<script src="http://img.dlwjdh.com/upload/saohei/index.js"></script>
</head>

<body>
    
        <!-- top -->

    <div class="top">

        <div class="center">

            <p>欢迎您进入陕西神鹰装备科技有限公司网站</p>

            <!-- 询盘 -->

            <div class="topxunpan">

                <div class="xp" id="xunpanText" data-tiptitle="请您登录网站后台查看！">

                    您有<i class="k_xunpan">12</i>条未读询盘信息!

                    <div id="xunpantip"></div>

                    &emsp;中文&nbsp;/&nbsp;<a href="">EN</a>

                </div>

            </div>

            <div class="top2">

                <a href="#wjdh-message" title="在线留言">在线留言</a>

            </div>

            <div class="clear"></div>

        </div>

    </div>

    <!-- header -->

    <div class="header">

        <div class="center">

            <h1><a href="/"><img src="http://img.dlwjdh.com/upload/8231/190925/d7857b7cdbea21170fafec329d63b27a@308X43.png" alt="陕西神鹰装备科技有限公司"></a></h1>

            <div class="header2">

                <h4>复材生产设备及制品研发、生产综合型企业</h4>

                <h5>服务于航天、航空、兵器、船舶等众多领域</h5>

            </div>

            <div class="header3">

                <img src="/templates/pc_wjdh/images/phone.png" alt="服务热线">

                <div>

                    <p>服务热线</p>

                    <span>029-86683353</span>

                </div>

            </div>

        </div>

    </div>

    <!-- nav -->

    <div class="webq_head_xx" >

        <div class="nav_xiala_xx" id="fixedNav">



            <div class="nav_xiala">

                <ul class="clears">

    

    <li>

      

      <a href="/" title="网站首页">网站首页 </a></li>

    

    <li>

      

      <a href="/p6/" title="热压罐">热压罐</a>

      

                        <div class="erji_xiala">

        

                        </div>

     

                    </li>



    <li>

      

      <a href="/p7/" title="缠绕机">缠绕机</a>

      

                        <div class="erji_xiala">

        

                        </div>

     

                    </li>



    <li>

      

      <a href="/p2/" title="复合材料制品">复合材料制品</a>

      

                        <div class="erji_xiala">

        

                            <i><a href="/csb/" title="测试板">测试板</a>

          

                                <div class="sanji_xiala_di"></div>

                                <div class="sanji_xiala">

          

                                </div>

     

                            </i>

        

                            <i><a href="/fdp/" title="发动盘">发动盘</a>

          

                                <div class="sanji_xiala_di"></div>

                                <div class="sanji_xiala">

          

                                </div>

     

                            </i>

        

                            <i><a href="/fwjc/" title="蜂窝夹层">蜂窝夹层</a>

          

                                <div class="sanji_xiala_di"></div>

                                <div class="sanji_xiala">

          

                                </div>

     

                            </i>

        

                            <i><a href="/gz/" title="管罩">管罩</a>

          

                                <div class="sanji_xiala_di"></div>

                                <div class="sanji_xiala">

          

                                </div>

     

                            </i>

        

                            <i><a href="/mj/" title="模具">模具</a>

          

                                <div class="sanji_xiala_di"></div>

                                <div class="sanji_xiala">

          

                                </div>

     

                            </i>

        

                            <i><a href="/nlg/" title="扭力管">扭力管</a>

          

                                <div class="sanji_xiala_di"></div>

                                <div class="sanji_xiala">

          

                                </div>

     

                            </i>

        

                            <i><a href="/qc/" title="前叉">前叉</a>

          

                                <div class="sanji_xiala_di"></div>

                                <div class="sanji_xiala">

          

                                </div>

     

                            </i>

        

                            <i><a href="/sb/" title="手把">手把</a>

          

                                <div class="sanji_xiala_di"></div>

                                <div class="sanji_xiala">

          

                                </div>

     

                            </i>

        

                            <i><a href="/txz/" title="天线罩">天线罩</a>

          

                                <div class="sanji_xiala_di"></div>

                                <div class="sanji_xiala">

          

                                </div>

     

                            </i>

        

                            <i><a href="/fdcb/" title="防弹插板">防弹插板</a>

          

                                <div class="sanji_xiala_di"></div>

                                <div class="sanji_xiala">

          

                                </div>

     

                            </i>

        

                        </div>

     

                    </li>



    <li class="another">

      

      <a href="/products/" title="产品中心">产品中心</a>

      

                        <div class="erji_xiala">

        

                            <i><a href="/p1/" title="复合材料生产设备">复合材料生产设备</a>

          

                                <div class="sanji_xiala_di"></div>

                                <div class="sanji_xiala">

          

          <span><a href="/p3/" title="排布机">排布机</a></span>

          

          <span><a href="/p8/" title="预浸料设备">预浸料设备</a></span>

          

          <span><a href="/p9/" title="液压釜">液压釜</a></span>

          

          <span><a href="/p4/" title="浸渍罐">浸渍罐</a></span>

          

          <span><a href="/p6/" title="热压罐">热压罐</a></span>

          

          <span><a href="/p7/" title="缠绕机">缠绕机</a></span>

          

          <span><a href="/ghl/" title="固化炉">固化炉</a></span>

          

                                </div>

     

                            </i>

        

                            <i><a href="/p2/" title="复合材料制品">复合材料制品</a>

          

                                <div class="sanji_xiala_di"></div>

                                <div class="sanji_xiala">

          

          <span><a href="/csb/" title="测试板">测试板</a></span>

          

          <span><a href="/fdp/" title="发动盘">发动盘</a></span>

          

          <span><a href="/fwjc/" title="蜂窝夹层">蜂窝夹层</a></span>

          

          <span><a href="/gz/" title="管罩">管罩</a></span>

          

          <span><a href="/mj/" title="模具">模具</a></span>

          

          <span><a href="/nlg/" title="扭力管">扭力管</a></span>

          

          <span><a href="/qc/" title="前叉">前叉</a></span>

          

          <span><a href="/sb/" title="手把">手把</a></span>

          

          <span><a href="/txz/" title="天线罩">天线罩</a></span>

          

          <span><a href="/fdcb/" title="防弹插板">防弹插板</a></span>

          

                                </div>

     

                            </i>

        

                        </div>

     

                    </li>



    <li>

      

      <a href="/case/" title="成功案例">成功案例</a>

      

                        <div class="erji_xiala">

        

                        </div>

     

                    </li>



    <li>

      

      <a href="/honor/" title="荣誉资质">荣誉资质</a>

      

                        <div class="erji_xiala">

        

                        </div>

     

                    </li>



    <li>

      

      <a href="/news/" title="新闻资讯">新闻资讯</a>

      

                        <div class="erji_xiala">

        

                            <i><a href="/meitibaodao/" title="公司头条">公司头条</a>

          

                            </i>

        

                            <i><a href="/yyxw/" title="行业资讯">行业资讯</a>

          

                            </i>

        

                            <i><a href="/question/" title="知识百科">知识百科</a>

          

                            </i>

        

                            <i><a href="/aktuelle/" title="时事聚焦">时事聚焦</a>

          

                            </i>

        

                        </div>

     

                    </li>



    <li>

      

      <a href="/aboutus/" title="神鹰简介">神鹰简介</a>

      

                        <div class="erji_xiala">

        

                        </div>

     

                    </li>



    <li>

      

      <a href="/contact/" title="联系神鹰">联系神鹰</a>

      

                        <div class="erji_xiala">

        

                        </div>

     

                    </li>



                </ul>

            </div>



        </div>

    </div>

 <!-- mbanner -->
    <div class="mbanner col-lg-12 col-md-12">
        <div class="row">
		
		<img src="http://img.dlwjdh.com/upload/8231/200825/1f74e930008d564148f9759b78ba43ce@1920X550.jpg" alt="产品中心">
		
		</div>
    </div>
    <div class="clearboth"></div>

    <!-- caseMenu -->
    <div class="caseMenuTop">
        <div class="container">
            <div class="row">
                <div class="caseMenuL col-lg-9 col-md-9 col-sm-9 col-xs-9">
                    <i><img src="/templates/pc_wjdh/img/locationIco.png" alt="当前位置"></i>
                            当前位置：<a href="/">首页</a>&nbsp;&gt;&nbsp;<a href="/products/">产品中心</a>&nbsp;&gt;&nbsp;<a href="/p1/">复合材料生产设备</a>&nbsp;&nbsp;&gt;&nbsp;<a href="/p6/">热压罐</a>
                    </div>
                    <div class="caseMenuR col-xs-3 col-sm-3 col-md-3 col-lg-3">
                    <i class="text-right"><a href="javascript:;" onClick="javascript :history.back(-1);">返回<img src="/templates/pc_wjdh/img/ca1.png" alt="返回"></a></i>
                </div>


                <div class="clearboth"></div>
            </div>
        </div>
    </div>
    <div class="clearboth"></div>
    
    <div class="proList">
        <div class="container">
            <div class="row">
                <div class="proListL  col-xs-12 col-lg-2-0">
                   
                    <div class="proListTop">
                        
						<img src="/templates/pc_wjdh/img/proL.png" alt="产品中心" class="proBg">
                        <div class="prouctsTitle">
                            <img src="/templates/pc_wjdh/img/products.png" alt="产品中心" class="pro-ico">
                            <h3>产品中心</h3>
                            <p>Product</p>
                        </div>
					  
                    </div>
                    <div class="row">

                        <div class="proList_classify">
	
   <div class="sidepromenu col-xs-6 col-sm-6 col-md-12 col-lg-12">
	   <div class="proListclass1"><i></i> <a href="/p1/" title="复合材料生产设备" class="proListclass2">复合材料生产设备</a><b></b></div>
	   <ul>
		   <li>
			   <p >
			   
				<a href="/p3/" title="排布机"><b></b><span>排布机</span></a>
				
				<a href="/p8/" title="预浸料设备"><b></b><span>预浸料设备</span></a>
				
				<a href="/p9/" title="液压釜"><b></b><span>液压釜</span></a>
				
				<a href="/p4/" title="浸渍罐"><b></b><span>浸渍罐</span></a>
				
				<a href="/p6/" title="热压罐" class="cur}"><b></b><span>热压罐</span></a>
				
				<a href="/p7/" title="缠绕机"><b></b><span>缠绕机</span></a>
				
				<a href="/ghl/" title="固化炉"><b></b><span>固化炉</span></a>
				
			   </p>
		   </li>
	   </ul>
   </div>
  
   <div class="sidepromenu col-xs-6 col-sm-6 col-md-12 col-lg-12">
	   <div class="proListclass1"><i></i> <a href="/p2/" title="复合材料制品" class="proListclass2">复合材料制品</a><b></b></div>
	   <ul>
		   <li>
			   <p >
			   
				<a href="/csb/" title="测试板"><b></b><span>测试板</span></a>
				
				<a href="/fdp/" title="发动盘"><b></b><span>发动盘</span></a>
				
				<a href="/fwjc/" title="蜂窝夹层"><b></b><span>蜂窝夹层</span></a>
				
				<a href="/gz/" title="管罩"><b></b><span>管罩</span></a>
				
				<a href="/mj/" title="模具"><b></b><span>模具</span></a>
				
				<a href="/nlg/" title="扭力管"><b></b><span>扭力管</span></a>
				
				<a href="/qc/" title="前叉"><b></b><span>前叉</span></a>
				
				<a href="/sb/" title="手把"><b></b><span>手把</span></a>
				
				<a href="/txz/" title="天线罩"><b></b><span>天线罩</span></a>
				
				<a href="/fdcb/" title="防弹插板"><b></b><span>防弹插板</span></a>
				
				<a href="/y/" title="翼"><b></b><span>翼</span></a>
				
			   </p>
		   </li>
	   </ul>
   </div>
  
</div>

                    </div>
                    <div class="row">
                        <div class="proHot">
                            <i><img src="/templates/pc_wjdh/img/proHotIco.png" alt="热门推荐">热门推荐</i>
                        
                        <div class="proList_sort">
                            <div class="swiper-container proList_sort1">
                                <ul class="swiper-wrapper">
                                    
									  <li class="swiper-slide col-xs-12 col-sm-12 col-md-12 col-lg-12">
									  <a href="/p6/1252675.html" class="proHotimg"><img src="http://img.dlwjdh.com/upload/8231/210322/9fd1347f284cbfe91e0a14c7233ea575.jpg" alt="实验室高温高压热压罐"></a>
									  <a href="/p6/1252675.html" class="proHot_txt">实验室高温高压热压罐</a>
									  </li>
									  
									  <li class="swiper-slide col-xs-12 col-sm-12 col-md-12 col-lg-12">
									  <a href="/p6/1115499.html" class="proHotimg"><img src="http://img.dlwjdh.com/upload/8231/201225/f0bcfcad78a0898edd82ae04aa152462.jpg" alt="热塑性热压罐"></a>
									  <a href="/p6/1115499.html" class="proHot_txt">热塑性热压罐</a>
									  </li>
									  
									  <li class="swiper-slide col-xs-12 col-sm-12 col-md-12 col-lg-12">
									  <a href="/p6/1059879.html" class="proHotimg"><img src="http://img.dlwjdh.com/upload/8231/201126/81fd6ae4fdae6291ce09c0ca43a209f6.jpg" alt="复材热压罐"></a>
									  <a href="/p6/1059879.html" class="proHot_txt">复材热压罐</a>
									  </li>
									  
									  <li class="swiper-slide col-xs-12 col-sm-12 col-md-12 col-lg-12">
									  <a href="/p6/880960.html" class="proHotimg"><img src="http://img.dlwjdh.com/upload/8231/200825/d85b74ead031f59558c12215bfa648aa.jpg" alt="航空热压罐"></a>
									  <a href="/p6/880960.html" class="proHot_txt">航空热压罐</a>
									  </li>
									  
                                </ul>
                               
                                <!-- Add Arrows -->
                                <div class="pro-next col-xs-6 col-sm-6 col-md-6 col-lg-6"><img src="/templates/pc_wjdh/img/proLL.png" alt="左"></div>
                                <div class="pro-prev col-xs-6 col-sm-6 col-md-6 col-lg-6"><img src="/templates/pc_wjdh/img/proLr.png" alt="右"></div>
                            </div>
                        </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="newsHot">
                            <i class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><img src="/templates/pc_wjdh/img/newsIco.png" alt="推荐新闻">推荐新闻</i>
                            <div class="newshotLine col-xs-12 col-sm-12 col-md-12 col-lg-12"></div>
                            <ul>
                                
							  	<li class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <a href="/yyxw/482725.html">
                                        <i>11-18</i>
                                        <span>国际复合材料与结构会议**在亚洲召开</span>
                                    </a>
                                </li>
							  
							  	<li class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <a href="/meitibaodao/1227144.html">
                                        <i>03-09</i>
                                        <span>神鹰给大家介绍热压罐具体有哪些种类？</span>
                                    </a>
                                </li>
							  
							  	<li class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <a href="/meitibaodao/1171906.html">
                                        <i>01-25</i>
                                        <span>碳纤维热压罐的碳纤维是什么样的材料</span>
                                    </a>
                                </li>
							  
							  	<li class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <a href="/meitibaodao/1018710.html">
                                        <i>11-06</i>
                                        <span>祝贺近日我公司承接了国内7米大型热压罐改造项目</span>
                                    </a>
                                </li>
							  
							  	<li class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <a href="/meitibaodao/1018656.html">
                                        <i>11-04</i>
                                        <span>祝贺近日我公司中标武汉航达航空科技发展有限公司多工位缠绕机项目</span>
                                    </a>
                                </li>
							  
							  	<li class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <a href="/meitibaodao/973719.html">
                                        <i>10-13</i>
                                        <span>强度超越芳纶、导电性首次突破10MS/m的碳纳米管纤维</span>
                                    </a>
                                </li>
							  
                          
                            </ul>
                        </div>

                    </div>
                </div>


                <div class="proListR  col-xs-12 col-lg-8-0">
                    <div class="proListRtop">
                        <i><img src="/templates/pc_wjdh/img/proListImg.png" alt="热压罐">热压罐</i>
                    </div>
                    <div class="proListRsort">
                        <span>
							
								<a href="/p6/1252675.html" title="实验室高温高压热压罐">实验室高温高压热压罐</a>
							  
								<a href="/p6/1115499.html" title="热塑性热压罐">热塑性热压罐</a>
							  
								<a href="/p6/1059879.html" title="复材热压罐">复材热压罐</a>
							  
								<a href="/p6/880960.html" title="航空热压罐">航空热压罐</a>
							  
								<a href="/p6/360852.html" title="防弹型热压罐">防弹型热压罐</a>
							  
								<a href="/p6/726833.html" title="机械臂热压罐">机械臂热压罐</a>
							  
                        </span>
                    </div>

                    <div class="proListCenter">
                        <div class="row1">
                        <ul>
                           
						
						   <li class="col-xs-6 col-sm-6 col-md-4 col-lg-4 ">
                           
                                <div class="productsBorer">
                                    <i><a href="/p6/1252675.html"><img src="http://img.dlwjdh.com/upload/8231/210322/9fd1347f284cbfe91e0a14c7233ea575.jpg" alt="实验室高温高压热压罐" class="caseImgList1"></a>
                                        <div class="caseListhide"></div>
                                    </i>
                                    <div class="proText">
                                        <a href="/p6/1252675.html" class="proListTitle">实验室高温高压热压罐</a>
                                        <a href="/p6/1252675.html" class="proMore">details</a>
                                    </div>

                                    <div class="border-left"></div>
                                    <div class="border-right"></div>
                                    <div class="border-top"></div>
                                    <div class="border-bottom"></div>
                                </div>
                               
                            </li>
						  
						   <li class="col-xs-6 col-sm-6 col-md-4 col-lg-4 ">
                           
                                <div class="productsBorer">
                                    <i><a href="/p6/1115499.html"><img src="http://img.dlwjdh.com/upload/8231/201225/f0bcfcad78a0898edd82ae04aa152462.jpg" alt="热塑性热压罐" class="caseImgList1"></a>
                                        <div class="caseListhide"></div>
                                    </i>
                                    <div class="proText">
                                        <a href="/p6/1115499.html" class="proListTitle">热塑性热压罐</a>
                                        <a href="/p6/1115499.html" class="proMore">details</a>
                                    </div>

                                    <div class="border-left"></div>
                                    <div class="border-right"></div>
                                    <div class="border-top"></div>
                                    <div class="border-bottom"></div>
                                </div>
                               
                            </li>
						  
						   <li class="col-xs-6 col-sm-6 col-md-4 col-lg-4 ">
                           
                                <div class="productsBorer">
                                    <i><a href="/p6/1059879.html"><img src="http://img.dlwjdh.com/upload/8231/201126/81fd6ae4fdae6291ce09c0ca43a209f6.jpg" alt="复材热压罐" class="caseImgList1"></a>
                                        <div class="caseListhide"></div>
                                    </i>
                                    <div class="proText">
                                        <a href="/p6/1059879.html" class="proListTitle">复材热压罐</a>
                                        <a href="/p6/1059879.html" class="proMore">details</a>
                                    </div>

                                    <div class="border-left"></div>
                                    <div class="border-right"></div>
                                    <div class="border-top"></div>
                                    <div class="border-bottom"></div>
                                </div>
                               
                            </li>
						  
						   <li class="col-xs-6 col-sm-6 col-md-4 col-lg-4 ">
                           
                                <div class="productsBorer">
                                    <i><a href="/p6/880960.html"><img src="http://img.dlwjdh.com/upload/8231/200825/d85b74ead031f59558c12215bfa648aa.jpg" alt="航空热压罐" class="caseImgList1"></a>
                                        <div class="caseListhide"></div>
                                    </i>
                                    <div class="proText">
                                        <a href="/p6/880960.html" class="proListTitle">航空热压罐</a>
                                        <a href="/p6/880960.html" class="proMore">details</a>
                                    </div>

                                    <div class="border-left"></div>
                                    <div class="border-right"></div>
                                    <div class="border-top"></div>
                                    <div class="border-bottom"></div>
                                </div>
                               
                            </li>
						  
						   <li class="col-xs-6 col-sm-6 col-md-4 col-lg-4 ">
                           
                                <div class="productsBorer">
                                    <i><a href="/p6/360852.html"><img src="http://img.dlwjdh.com/upload/8231/200601/92f0dd9b5db365573157734761660604.jpg" alt="防弹型热压罐" class="caseImgList1"></a>
                                        <div class="caseListhide"></div>
                                    </i>
                                    <div class="proText">
                                        <a href="/p6/360852.html" class="proListTitle">防弹型热压罐</a>
                                        <a href="/p6/360852.html" class="proMore">details</a>
                                    </div>

                                    <div class="border-left"></div>
                                    <div class="border-right"></div>
                                    <div class="border-top"></div>
                                    <div class="border-bottom"></div>
                                </div>
                               
                            </li>
						  
						   <li class="col-xs-6 col-sm-6 col-md-4 col-lg-4 ">
                           
                                <div class="productsBorer">
                                    <i><a href="/p6/726833.html"><img src="http://img.dlwjdh.com/upload/8231/200601/2df35fda937753a15dde512708ac60d3.jpg" alt="机械臂热压罐" class="caseImgList1"></a>
                                        <div class="caseListhide"></div>
                                    </i>
                                    <div class="proText">
                                        <a href="/p6/726833.html" class="proListTitle">机械臂热压罐</a>
                                        <a href="/p6/726833.html" class="proMore">details</a>
                                    </div>

                                    <div class="border-left"></div>
                                    <div class="border-right"></div>
                                    <div class="border-top"></div>
                                    <div class="border-bottom"></div>
                                </div>
                               
                            </li>
						  
                    </div>
                        </ul>
                    </div>
                    <div class="clearboth"></div>
                    <div class="pro_page">
                        <ul class="pagination">
                           
                        </ul>
                    </div>
                    
                </div>
            </div>
            
        </div>
    </div>



 
     <script src="/templates/pc_wjdh/js/n/jquery.min.js"></script>
    <script src="/templates/pc_wjdh/js/n/bootstrap.min.js"></script>
    <script src="/templates/pc_wjdh/js/n/swiper-3.4.2.min.js"></script>
       <script src="/templates/pc_wjdh/js/n/WJDH_common.js"></script>
    <script src="/templates/pc_wjdh/js/n/rem.min.js"></script>


           <!-- footer -->
    <div class="footer">
        <div class="center">
            <div class="footer1">
                <ul class="footer1-1">
                    <li>
                        <h4>产品中心</h4>
                        <h5>PRODUCT CENTER </h5>
          
                        <a href="/p1/" title="复合材料生产设备">复合材料生产设备</a>
          
                        <a href="/p2/" title="复合材料制品">复合材料制品</a>
          
                    </li>
                    <li>
                        <h4>直通车</h4>
                        <h5>THROUGH TRAIN </h5>
        
        <a href="http://www.seet.net.cn/p7/361084.html" title="缠绕机" target="_blank">缠绕机</a>
        
        <a href="http://www.seet.net.cn/p3/382589.html" title="排布机" target="_blank">排布机</a>
        
        <a href="http://www.seet.net.cn/p6/360852.html" title="热压罐" target="_blank">热压罐</a>
        
                    </li>
                    <li>
                        <h4>新闻中心</h4>
                        <h5>NEWS  CENTER</h5>
          
                        <a href="/meitibaodao/" title="公司头条">公司头条</a>
          
                        <a href="/yyxw/" title="行业资讯">行业资讯</a>
          
                        <a href="/question/" title="知识百科">知识百科</a>
          
                        <a href="/aktuelle/" title="时事聚焦">时事聚焦</a>
          
                    </li>
                    <li>
                        <h4>关于我们</h4>
                        <h5>ABOUT US</h5>
          
                        <a href="/customs/" title="研发中心">研发中心</a>
          
                        <a href="/honor/" title="荣誉资质">荣誉资质</a>
          
                        <a href="/aboutus/" title="神鹰简介">神鹰简介</a>
          
                        <a href="/album/" title="厂区基地">厂区基地</a>
          
                    </li>
                </ul>
                <div class="footer1-2">
                    <div class="or-card">
                        <img src="http://img.dlwjdh.com/upload/8231/190927/ce5cee8594d2619adc82c2a1a705de63@256X254.jpg" alt="微信二维码">
                    </div>
                    <p>微信二维码</p>
                </div>
            </div>
            <ul class="footer2">
               <li>
                   <img src="/templates/pc_wjdh/images/footer1.png" alt="咨询热线">
                   <p><span>咨询热线：</span><b>029-86683353</b></p>
               </li>
                <li>
                    <img src="/templates/pc_wjdh/images/footer2.png" alt="邮箱">
                    <p><span>邮箱：</span><b>seet11302@126.com</b></p>
                </li>
                <li>
                    <img src="/templates/pc_wjdh/images/footer3.png" alt="地址">
                    <p><span>地址：</span><i>西安市经济技术开发区一方中港国际2座1单元13层</i></p>
                </li>
            </ul>
            <div class="footer3">
                <div class="footer3-1">
                    <span>Copyright&nbsp;&copy;&nbsp;陕西神鹰装备科技有限公司&nbsp;&nbsp;版权所有</span>
                    <span>备案号：<a href="http://beian.miit.gov.cn" target="_blank" title="陕ICP备19021117号-1" rel="nofollow">陕ICP备19021117号-1</a></span>
                    <span>
                        <a href="/sitemap.html" title="网站地图">网站地图</a>&nbsp;&nbsp;<a href="/rss.xml" title="RSS">RSS </a>&nbsp;&nbsp;<a href="/sitemap.xml" title="XML">XML </a>
                   </span>
                </div>
                <div class="footer3-2">
                    <span>技术支持：<script src="/api/message.ashx?action=jjzc"></script></span>
                    <span><a href="http://www.wjdhcms.com" target="_blank" rel="external nofollow" title="万家灯火"><img class="wjdh-ico1" src="http://img.dlwjdh.com/upload/5.png" width="99px" height="18px" title="万家灯火" alt="万家灯火"></a></span>
                    <span><script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1278001336'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s11.cnzz.com/stat.php%3Fid%3D1278001336%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script></span>
                    <span><a href="http://trust.wjdhcms.com/#/pc?url=www.seet.net.cn" target="_blank" rel="external nofollow"><img  class="wjdh-ico2" src=http://img.dlwjdh.com/upload/trust/1.png></a></span>
                </div>
            </div>
        </div>
    </div>
    <!--全局使用js，请放于footer-->
    <script src="/templates/pc_wjdh/js/nav.js"></script>
    
<script type="text/javascript" src="http://tongji.wjdhcms.com/js/tongji.js?siteid=2004e0f2b74655ee92d3a6af6bdb6626"></script><script type="text/javascript" src="http://seet.s1.dlwjdh.com/upload/8231/kefu.js?color=1d2088"></script>
<script src="/templates/pc_wjdh/js/n/base.js" type="text/javascript" charset="utf-8"></script>

   <script src="/templates/pc_wjdh/js/n/common.js"></script>
   <style>
	.breadcrumb a:hover,.side-bar.side-bar-tit h2,.wjdh-title h3,.wjdh-title h3 a,.pages a:hover,.pages span:hover,.relevant.title h3,.wjdh-h3 h3 a,.image-list.content ul li:hover.title-a,.text-list ul li:hover dd a,.express-lane dl dd a:hover,.bottom-contact.tel p span,.list01 .list ul li:hover.date span,.list02 .list ul li:hover.info.title-a,.news-list ul li:hover.more,.news-center-company.company-list.title dl,.news-center-company.company-list.title.title-h3 h3 a,.news-center-company.company-list.list ul li:hover.date span,.product-list ul li:hover.info.title-a,.product-list ul li:hover.info.more,.prohead.hright.title-a,.prohead.hright.info ul li,.prohead.hright.info ul li a,.prohead.hright.tel,.prohead.hright.tel span{color:#1d2088}.wjdh-search.search-s,.side-bar.side-bar-tit i,.side-bar dl dt,.side-bar dl.cur a,.side-bar dl dd:hover a,.side-bar dl.tag a:hover,.side-contact.side-contact-phone,.wjdh-title.tagcell span,.pages.current,.image-list.content ul li.border-top,.image-list.content ul li.border-right,.image-list.content ul li.border-bottom,.image-list.content ul li.border-left,.image-list.content ul li:hover.more,.text-list ul li.border-top,.text-list ul li.border-bottom,.text-list dl dt i,.cat-menu.menu-list.cur a,.cat-menu.menu-list span:hover a,.list01 .list01-top:hover.info.more,.list01 .list01-top.tag-hot,.list01 .list ul li:hover.more,.list02 .list ul li:hover.info.more,.list03 .list ul li.info i em,.news-center-company.company-top dl,.news-center-company.company-top ul li:hover.more,.news-center-company.company-list.list ul li:hover.more,.industry.industry-left.industry-title,.industry.industry-right.list ul li:hover,.industry.industry-right.list ul li:hover.more,.hot-rec.content.info.title-a,.hot-rec.content.info.online,.message-page-box.submit:hover,.prohead.hright.online a,.newsTop ul li:hover .newsTopcenter{background-color:#1d2088}
.wjdh-search.search-s,.pages a:hover,.pages span:hover,.pages.current,.image-list.content ul li:hover.more,.list01 .list01-top:hover.info.more,.list02 .list ul li:hover,.list02 .list ul li:hover.info.more,.news-list ul li:hover.more,.news-center-company.company-top ul li:hover.more,.news-center-company.company-list.list ul li:hover,.product-list ul li:hover,.wjdh-search.search-s,.list01 .list ul li:hover{border:1px solid#1d2088}.wjdh-title h3,.news-center-company.company-list.title.title-h3 h3 a,.message-page-box.on{border-bottom:1px solid#1d2088}.cat-menu.menu-list.cur:before,.cat-menu.menu-list span:hover:before{border-top:10px solid#1d2088}.proListclass1,.proList_classify ul li p a b,.proListRsort a::before,.border-left,.border-right,.border-top,.border-bottom,.pagination span.current,.pagination a:hover,.pagination span:hover,.productsCtl,.caseTab ul li:hover,.a-bth:hover,.border-proleft,.border-proright,.border-protop,.border-probottom,.caseLdd.button_text_container,.caseLdd:hover.button_text_container,.swiper-pagination-bullet-active,.newsQa ul li p span,.news_classify ul li b,.contact ul li:hover.contactTop,.driving-way.hd li.on,.proBg,.newsTop ul li:hover.newsTopcenter,.productsMore:hover,.driving-way.map-tab#result:hover,.proListRsort1 a::before,.messageBth:hover,.caseLdd:hover .button_text_container,.caseLdd .button_text_container{background-color:#1d2088}
.proList_sort ul li:hover.proHot_txt,.newsHot ul li:hover i,.newsHot ul li:hover span,.proListRsort a:hover,.proListRsort a:hover,.proListCenter ul li:hover a.proListTitle,.relevantImg ul li:hover.relevantImgMore,.caseMenuR a:hover,.honorBox ul li:hover.honorImg1,.aboutTitle a,.newsListLcenter:hover.newsListLtext a,.newsListRtop:hover.newsListRtopR a,.newsQa ul li:hover a,.newsCenterTop:hover h4 a,.newsCenterb ul li:hover a,.newsListRtop:hover span,.newsListRtop:hover b,.honor ul li:hover.honorMore,.relevant a:hover,.caseTitleR ul li:hover.ctc,.caseRe i,.caseMenuL:hover a,.caseRer a:hover,.proListRsort1 a:hover,.caseTitleR ul li.gaoliang.ctc,.siteMapBox ul li a.siteTitle,.siteMapBox ul li.siteMapMt a.siteMore:hover,.siteMapBox ul li a.siteMore:hover,.siteMapBox ul li a.siteMore:hover.siteMapMt span a:hover,.siteMapMt span a:hover{color:#1d2088}.caseREimg img{border-left:180px solid transparent;-webkit-filter:drop-shadow(-180px 0 0px#1d2088);filter:drop-shadow(-180px 0 0px#1d2088)}.preview ul li.active-nav,.preview ul li.swiper-slide-active:hover,.caseTitleR ul li span::before,.preview ul li.swiper-slide-active,.driving-way.map-tab.trip-mode a:hover i,.driving-way.map-tab.trip-mode a.active i{border-color:#1d2088}.view.arrow-right:hover{background:rgba(29,32,136,1)}.view.arrow-left:hover{background:rgba(29,32,136,1)}</style>
</body>

</html>
